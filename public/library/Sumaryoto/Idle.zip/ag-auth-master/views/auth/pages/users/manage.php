<h2>Manage Users</h2>

<?php echo $this->table->generate(); ?>