<h2>User Successfully Deleted</h2>

<p>The user has now been deleted.</p>